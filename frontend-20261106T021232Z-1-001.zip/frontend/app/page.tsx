"use client";

import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { useApi, type Page, type Stats } from "@/lib/api";
import { AuthorSearch } from "@/components/author-search";
import { AuthorCard } from "@/components/author-bits";
import { ErrorState, LoadingBlock } from "@/components/states";

const FEATURES = [
  { n: "I", title: "Author Match", href: "/search", text: "Parta de um autor consagrado e receba escritores próximos — inclusive os que a fama esqueceu — com o porquê de cada afinidade." },
  { n: "II", title: "Match Breakdown", href: "/search", text: "Coloque dois autores lado a lado: proximidade textual, gêneros, temas e traços de estilo, tudo calculado a partir dos textos." },
  { n: "III", title: "Reading DNA", href: "/reading-dna", text: "Escolha de três a cinco favoritos. O sistema compõe o seu perfil de leitor e procura quem combina com ele." },
  { n: "IV", title: "Meu Universo Literário", href: "/library", text: "Uma biblioteca pessoal para guardar autores, livros e descobertas, e acompanhar o que você está lendo." },
];

export default function Home() {
  const stats = useApi<Stats>("/meta/stats");
  const lesser = useApi<Page>("/authors?tier=lesser_known&limit=4&sort=popularity");
  const canon = useApi<Page>("/authors?sort=popularity&limit=4");
  const picks = lesser.data?.items.length ? lesser : canon;

  return (
    <div className="fade-in">
      <section className="rule-strong grid gap-10 pt-10 pb-14 md:grid-cols-[1.4fr_1fr]">
        <div>
          <p className="eyebrow">Edição de descoberta</p>
          <h1 className="mt-4 text-5xl md:text-7xl">
            O próximo autor que você vai amar <em className="text-accent">talvez ninguém tenha te indicado.</em>
          </h1>
          <p className="mt-6 max-w-xl text-lg text-ink-2">
            Lemos os livros para comparar escritores pela matéria do texto — vocabulário, temas, ritmo da frase —
            e não pela popularidade. Comece por alguém que você já conhece.
          </p>
          <AuthorSearch className="mt-8 max-w-xl" submitToSearch autoFocus />
        </div>
        <aside className="self-end border-l border-rule pl-6">
          <p className="eyebrow">O corpus, em números</p>
          {stats.loading && <LoadingBlock lines={3} />}
          {stats.error && <ErrorState error={stats.error} onRetry={stats.reload} />}
          {stats.data && (
            <dl className="mt-4 grid grid-cols-2 gap-x-6 gap-y-5">
              {[
                ["autores", stats.data.authors], ["obras", stats.data.works],
                ["trechos lidos", stats.data.chunks], ["pares comparados", stats.data.pairs],
              ].map(([k, v]) => (
                <div key={k as string}>
                  <dd className="font-display text-4xl">{Number(v).toLocaleString("pt-BR")}</dd>
                  <dt className="eyebrow mt-1">{k}</dt>
                </div>
              ))}
            </dl>
          )}
          {stats.data?.model && (
            <p className="mt-5 text-sm text-muted">Embeddings: <span className="num">{stats.data.model.split("/").pop()}</span></p>
          )}
        </aside>
      </section>

      <section className="rule grid gap-8 py-12 sm:grid-cols-2 lg:grid-cols-4">
        {FEATURES.map((f) => (
          <Link key={f.n} href={f.href} className="group block">
            <p className="num text-sm text-accent">{f.n}.</p>
            <h2 className="mt-2 text-2xl group-hover:text-accent">{f.title}</h2>
            <p className="mt-2 text-ink-2">{f.text}</p>
          </Link>
        ))}
      </section>

      <section className="rule-strong pt-6">
        <div className="flex items-baseline justify-between">
          <h2 className="text-3xl">{lesser.data?.items.length ? "Menos conhecidos, para começar" : "Para começar"}</h2>
          <Link href="/search" className="eyebrow flex items-center gap-1 hover:text-accent">Todos os autores <ArrowRight className="size-3" /></Link>
        </div>
        {picks.loading && <LoadingBlock lines={2} />}
        {picks.error && <ErrorState error={picks.error} onRetry={picks.reload} />}
        {picks.data && (
          <div className="mt-6 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {picks.data.items.map((a) => (
              <AuthorCard key={a.id} a={a} footer={
                <Link href={`/authors/${a.id}/matches`} className="eyebrow flex items-center gap-1 hover:text-accent">Ver afinidades <ArrowRight className="size-3" /></Link>
              } />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
