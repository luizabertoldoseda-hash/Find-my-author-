"use client";

import Link from "next/link";
import { Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { ArrowRight } from "lucide-react";
import { qs, useApi, type AuthorSummary, type Facets, type Page } from "@/lib/api";
import { AuthorSearch } from "@/components/author-search";
import { AuthorCard, PageHeader } from "@/components/author-bits";
import { EmptyState, ErrorState, LoadingBlock } from "@/components/states";
import { Select } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { TIER_LABEL } from "@/lib/utils";

const PAGE = 24;

function SearchInner() {
  const sp = useSearchParams();
  const router = useRouter();
  const q = sp.get("q") ?? "";
  const genre = sp.get("genre") ?? "";
  const tier = sp.get("tier") ?? "";
  const sort = sp.get("sort") ?? "name";
  const offset = Number(sp.get("offset") ?? 0);

  const facets = useApi<Facets>("/meta/facets");
  const hits = useApi<AuthorSummary[]>(q ? `/authors/search${qs({ q, limit: 50 })}` : null);
  const page = useApi<Page>(q ? null : `/authors${qs({ genre, tier, sort, limit: PAGE, offset })}`);

  const set = (patch: Record<string, string>) => {
    const next = new URLSearchParams(sp.toString());
    Object.entries(patch).forEach(([k, v]) => (v ? next.set(k, v) : next.delete(k)));
    if (!("offset" in patch)) next.delete("offset");
    router.push(`/search?${next.toString()}`);
  };

  const list = q ? hits : page;
  const items = q ? hits.data : page.data?.items;

  return (
    <>
      <PageHeader eyebrow="01 · Autores" title={q ? <>Resultados para <em className="text-accent">“{q}”</em></> : "Todos os autores do corpus"}>
        Escolha um autor para ver quem escreve de forma parecida.
      </PageHeader>
      <AuthorSearch className="max-w-xl" submitToSearch placeholder="Buscar pelo nome" />

      {!q && (
        <div className="mt-8 flex flex-wrap items-end gap-4">
          <Select label="Gênero" value={genre} onChange={(e) => set({ genre: e.target.value })}>
            <option value="">Todos</option>
            {facets.data?.genres.map((g) => <option key={g.value} value={g.value}>{g.value} ({g.count})</option>)}
          </Select>
          <Select label="Notoriedade" value={tier} onChange={(e) => set({ tier: e.target.value })}
                  disabled={!facets.data?.tiers.length} title={!facets.data?.tiers.length ? "Sem dados de popularidade neste corpus" : undefined}>
            <option value="">Todas</option>
            {facets.data?.tiers.map((t) => <option key={t.value} value={t.value}>{TIER_LABEL[t.value]} ({t.count})</option>)}
          </Select>
          <Select label="Ordenar" value={sort} onChange={(e) => set({ sort: e.target.value })}>
            <option value="name">Nome</option>
            <option value="popularity">Mais lidos no Gutenberg</option>
            <option value="birth_year">Ano de nascimento</option>
          </Select>
          {(genre || tier) && <Button variant="ghost" size="sm" onClick={() => set({ genre: "", tier: "" })}>Limpar filtros</Button>}
        </div>
      )}

      {list.loading && <LoadingBlock lines={6} />}
      {list.error && <ErrorState error={list.error} onRetry={list.reload} />}
      {items && items.length === 0 && (
        <EmptyState title="Nenhum autor encontrado">
          {q ? "Esse nome não está no corpus. Tente outro, ou navegue pela lista completa." : "Nenhum autor com esses filtros."}
        </EmptyState>
      )}
      {items && items.length > 0 && (
        <>
          {!q && page.data && <p className="eyebrow mt-8">{page.data.total} autores</p>}
          <div className="mt-4 grid gap-x-8 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
            {items.map((a) => (
              <AuthorCard key={a.id} a={a} footer={
                <div className="flex gap-4">
                  <Link href={`/authors/${a.id}/matches`} className="eyebrow flex items-center gap-1 text-accent hover:text-ink">Author Match <ArrowRight className="size-3" /></Link>
                  <Link href={`/authors/${a.id}`} className="eyebrow hover:text-accent">Perfil</Link>
                </div>
              } />
            ))}
          </div>
          {!q && page.data && page.data.total > PAGE && (
            <div className="mt-10 flex items-center gap-4">
              <Button variant="outline" size="sm" disabled={offset === 0} onClick={() => set({ offset: String(Math.max(0, offset - PAGE)) })}>Anterior</Button>
              <span className="num text-sm text-muted">{offset + 1}–{Math.min(offset + PAGE, page.data.total)} de {page.data.total}</span>
              <Button variant="outline" size="sm" disabled={offset + PAGE >= page.data.total} onClick={() => set({ offset: String(offset + PAGE) })}>Próxima</Button>
            </div>
          )}
        </>
      )}
    </>
  );
}

export default function SearchPage() {
  return <Suspense fallback={<LoadingBlock />}><SearchInner /></Suspense>;
}
