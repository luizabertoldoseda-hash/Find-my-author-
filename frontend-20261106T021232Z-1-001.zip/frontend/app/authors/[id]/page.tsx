"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { ArrowRight, ExternalLink } from "lucide-react";
import { useApi, type Author, type MatchList } from "@/lib/api";
import { PageHeader, SaveButton, Tags, TierBadge } from "@/components/author-bits";
import { StyleRadar, ThemeBars } from "@/components/charts";
import { EmptyState, ErrorState, LoadingBlock } from "@/components/states";
import { Button } from "@/components/ui/button";
import { years } from "@/lib/utils";

export default function AuthorPage() {
  const { id } = useParams<{ id: string }>();
  const { data: a, error, loading, reload } = useApi<Author>(`/authors/${id}`);
  const top = useApi<MatchList>(`/authors/${id}/matches?limit=3`);

  if (loading) return <LoadingBlock lines={8} />;
  if (error) return <ErrorState error={error} onRetry={reload} />;
  if (!a) return null;

  const themes = Object.entries(a.text_theme_scores).map(([theme, z]) => ({ theme, a: z })).sort((x, y) => Number(y.a) - Number(x.a));

  return (
    <article className="fade-in">
      <PageHeader eyebrow={`Perfil · ${years(a.birth_year, a.death_year) ?? "datas não informadas"}${a.curation_region ? ` · ${a.curation_region}` : ""}`} title={a.name}>
        <div className="flex flex-wrap items-center gap-3">
          <TierBadge tier={a.popularity_tier} />
          <Button asChild variant="accent" size="sm"><Link href={`/authors/${a.id}/matches`}>Ver autores semelhantes <ArrowRight /></Link></Button>
          <SaveButton path="/library/authors" body={{ author_id: a.id }} label="Salvar autor" />
        </div>
      </PageHeader>

      <div className="grid gap-12 md:grid-cols-[1.5fr_1fr]">
        <section>
          <h2 className="eyebrow">Biografia</h2>
          {a.bio ? (
            <>
              <p className="dropcap mt-3 whitespace-pre-line text-lg">{a.bio}</p>
              <p className="eyebrow mt-2">Fonte: {a.bio_source === "openlibrary" ? "Open Library" : a.bio_source}</p>
            </>
          ) : (
            <p className="mt-3 text-muted">Nenhuma biografia disponível nas fontes consultadas.</p>
          )}

          <h2 className="eyebrow mt-10">Obras no corpus</h2>
          <ul className="mt-3 divide-y divide-rule border-y border-rule">
            {a.works.map((w) => (
              <li key={w.id} className="flex items-center gap-4 py-3">
                {w.cover_url ? <img src={w.cover_url} alt="" className="h-16 w-11 border border-rule object-cover" /> : <div className="h-16 w-11 bg-paper-2" />}
                <div className="flex-1">
                  <p className="font-display text-lg leading-tight">{w.title}</p>
                  <p className="num text-xs text-muted">{w.n_words.toLocaleString("pt-BR")} palavras{w.published_date ? ` · ${w.published_date.slice(0, 4)}` : ""}</p>
                </div>
                <SaveButton path="/library/books" body={{ work_id: w.id }} label="Quero ler" savedLabel="Na lista" />
              </li>
            ))}
          </ul>
        </section>

        <aside className="space-y-8">
          <div><h2 className="eyebrow mb-2">Gêneros</h2>{a.genres.length ? <Tags items={a.genres} max={8} /> : <p className="text-muted">Sem gênero mapeado nas fontes.</p>}</div>
          {a.subgenres.length > 0 && <div><h2 className="eyebrow mb-2">Subgêneros</h2><Tags items={a.subgenres} max={8} /></div>}
          <div><h2 className="eyebrow mb-2">Temas (metadados)</h2>{a.themes.length ? <Tags items={a.themes} max={8} /> : <p className="text-muted">Sem temas catalogados.</p>}</div>
          <div><h2 className="eyebrow mb-2">Temas inferidos do texto</h2><Tags items={a.text_themes} variant="accent" /></div>
          <div><h2 className="eyebrow mb-2">Vocabulário característico</h2><p className="italic text-ink-2">{a.keywords.slice(0, 12).join(" · ")}</p></div>
          {a.sources.length > 0 && (
            <div>
              <h2 className="eyebrow mb-2">Proveniência</h2>
              <ul className="space-y-1 text-sm text-ink-2">
                {a.sources.map((s) => (
                  <li key={s.source + s.source_id}>
                    {s.url ? <a href={s.url} target="_blank" rel="noreferrer" className="link inline-flex items-center gap-1">{s.source} <ExternalLink className="size-3" /></a> : s.source}
                    {s.retrieved_at && <span className="num text-xs text-muted"> · {s.retrieved_at.slice(0, 10)}</span>}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </aside>
      </div>

      <section className="rule-strong mt-14 grid gap-12 pt-6 md:grid-cols-2">
        <div>
          <h2 className="text-2xl">Assinatura de estilo</h2>
          <p className="mt-1 text-sm text-ink-2">Medidas calculadas sobre os trechos amostrados, em percentil frente aos demais autores.</p>
          <StyleRadar data={a.style.map((s) => ({ label: s.label, a: s.percentile }))} nameA={a.name} />
        </div>
        <div>
          <h2 className="text-2xl">Ênfase temática</h2>
          <p className="mt-1 text-sm text-ink-2">Quanto os trechos se aproximam de cada tema, comparado à média do corpus.</p>
          <ThemeBars data={themes} nameA={a.name} />
        </div>
      </section>

      <section className="rule-strong mt-14 pt-6">
        <div className="flex items-baseline justify-between">
          <h2 className="text-2xl">Afinidades mais fortes</h2>
          <Link href={`/authors/${a.id}/matches`} className="eyebrow flex items-center gap-1 hover:text-accent">Lista completa <ArrowRight className="size-3" /></Link>
        </div>
        {top.loading && <LoadingBlock lines={2} />}
        {top.error && <ErrorState error={top.error} onRetry={top.reload} />}
        {top.data && top.data.items.length === 0 && <EmptyState title="Sem recomendações" />}
        <ol className="mt-4 grid gap-6 md:grid-cols-3">
          {top.data?.items.map((m) => (
            <li key={m.author.id} className="border-t border-ink pt-3">
              <span className="num text-xs text-muted">{String(m.rank).padStart(2, "0")}</span>
              <Link href={`/compare/${a.id}/${m.author.id}`} className="block font-display text-xl hover:text-accent">{m.author.name}</Link>
              <p className="num text-sm text-ink-2">score {m.score.toFixed(2)} · acima de {m.semantic_percentile.toFixed(0)}% dos pares</p>
            </li>
          ))}
        </ol>
      </section>
    </article>
  );
}
