"use client";

import Link from "next/link";
import { Suspense } from "react";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import { ArrowRight } from "lucide-react";
import { qs, useApi, type Facets, type MatchList } from "@/lib/api";
import { PageHeader, SaveButton, Tags, TierBadge } from "@/components/author-bits";
import { ScoreMeter } from "@/components/charts";
import { EmptyState, ErrorState, LoadingBlock } from "@/components/states";
import { Select } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { TIER_LABEL, years } from "@/lib/utils";

const MODE_HELP: Record<string, string> = {
  hybrid: "Texto (60%) + gêneros, subgêneros e temas dos metadados. Componentes sem dados são ignorados e os pesos, renormalizados.",
  semantic: "Só a proximidade entre os embeddings dos textos (all-MiniLM-L6-v2).",
  metadata: "Só gêneros, subgêneros e temas catalogados — útil para comparar com a leitura do texto.",
};

function MatchesInner() {
  const { id } = useParams<{ id: string }>();
  const sp = useSearchParams();
  const router = useRouter();
  const f = {
    mode: sp.get("mode") ?? "hybrid", genre: sp.get("genre") ?? "", subgenre: sp.get("subgenre") ?? "",
    theme: sp.get("theme") ?? "", tier: sp.get("tier") ?? "",
  };
  const facets = useApi<Facets>("/meta/facets");
  const { data, error, loading, reload } = useApi<MatchList>(`/authors/${id}/matches${qs({ ...f, limit: 12 })}`);

  const set = (patch: Partial<typeof f>) => {
    const next = new URLSearchParams(sp.toString());
    Object.entries(patch).forEach(([k, v]) => (v ? next.set(k, v) : next.delete(k)));
    router.replace(`/authors/${id}/matches?${next.toString()}`, { scroll: false });
  };
  const anyFilter = f.genre || f.subgenre || f.theme || f.tier;

  return (
    <>
      <PageHeader eyebrow="Author Match" title={data ? <>Quem escreve como <Link href={`/authors/${id}`} className="text-accent hover:underline">{data.reference.name}</Link>?</> : "Autores semelhantes"}>
        Ordenado por afinidade literária, não por popularidade. Cada recomendação mostra de onde vem o score.
      </PageHeader>

      <div className="flex flex-wrap items-end gap-4 border-b border-rule pb-5">
        <div className="flex flex-col gap-1">
          <span className="eyebrow">Critério</span>
          <div className="flex border border-ink" role="radiogroup" aria-label="Critério de similaridade">
            {(["hybrid", "semantic", "metadata"] as const).map((m) => (
              <button key={m} role="radio" aria-checked={f.mode === m} onClick={() => set({ mode: m === "hybrid" ? "" : m })}
                      className={`h-9 cursor-pointer px-3 font-mono text-[0.7rem] uppercase tracking-wider ${f.mode === m ? "bg-ink text-paper" : "hover:bg-paper-2"}`}>
                {{ hybrid: "Híbrido", semantic: "Só texto", metadata: "Só metadados" }[m]}
              </button>
            ))}
          </div>
        </div>
        <Select label="Gênero" value={f.genre} onChange={(e) => set({ genre: e.target.value })} disabled={!facets.data?.genres.length}>
          <option value="">Todos</option>
          {facets.data?.genres.map((g) => <option key={g.value} value={g.value}>{g.value}</option>)}
        </Select>
        <Select label="Subgênero" value={f.subgenre} onChange={(e) => set({ subgenre: e.target.value })} disabled={!facets.data?.subgenres.length}>
          <option value="">Todos</option>
          {facets.data?.subgenres.map((g) => <option key={g.value} value={g.value}>{g.value}</option>)}
        </Select>
        <Select label="Tema" value={f.theme} onChange={(e) => set({ theme: e.target.value })} disabled={!facets.data?.themes.length}>
          <option value="">Todos</option>
          {facets.data?.themes.map((g) => <option key={g.value} value={g.value}>{g.value}</option>)}
        </Select>
        <Select label="Notoriedade" value={f.tier} onChange={(e) => set({ tier: e.target.value })} disabled={!facets.data?.tiers.length}>
          <option value="">Todas</option>
          {facets.data?.tiers.map((t) => <option key={t.value} value={t.value}>{TIER_LABEL[t.value]}</option>)}
        </Select>
        {anyFilter && <Button variant="ghost" size="sm" onClick={() => set({ genre: "", subgenre: "", theme: "", tier: "" })}>Limpar</Button>}
      </div>
      <p className="mt-3 text-sm text-muted">{MODE_HELP[f.mode]}</p>

      {loading && <LoadingBlock lines={8} label="Calculando afinidades" />}
      {error && <ErrorState error={error} onRetry={reload} />}
      {data && data.items.length === 0 && (
        <EmptyState title="Nenhum autor passa por esses filtros">Remova algum filtro para ver mais recomendações.</EmptyState>
      )}
      <ol className="mt-6 divide-y divide-rule">
        {data?.items.map((m) => (
          <li key={m.author.id} className="fade-in grid gap-6 py-8 md:grid-cols-[3rem_1.3fr_1fr]">
            <span className="font-display text-4xl text-muted">{m.rank}</span>
            <div>
              <div className="flex flex-wrap items-baseline gap-3">
                <Link href={`/authors/${m.author.id}`} className="font-display text-3xl hover:text-accent">{m.author.name}</Link>
                <span className="num text-xs text-muted">{years(m.author.birth_year, m.author.death_year)}</span>
                <TierBadge tier={m.author.popularity_tier} />
              </div>
              {m.bio && <p className="mt-2 line-clamp-3 text-ink-2">{m.bio}</p>}
              <p className="mt-3">{m.explanation}</p>
              {m.representative_works.length > 0 && (
                <p className="mt-3 text-sm text-ink-2"><span className="eyebrow mr-2">Obras</span>{m.representative_works.map((w) => w.title).join(" · ")}</p>
              )}
              <div className="mt-3 flex flex-wrap gap-4">
                <div><Tags items={m.author.genres} max={3} /></div>
                {m.subgenres.length > 0 && <Tags items={m.subgenres} max={2} />}
              </div>
            </div>
            <div className="space-y-4 md:border-l md:border-rule md:pl-6">
              <div>
                <div className="flex items-baseline justify-between">
                  <span className="eyebrow">Score ({{ hybrid: "híbrido", semantic: "texto", metadata: "metadados" }[m.mode]})</span>
                  <span className="font-display text-3xl">{m.score.toFixed(2)}</span>
                </div>
                <ScoreMeter value={m.score} />
                <p className="num mt-1 text-xs text-muted">cosseno {m.semantic_raw.toFixed(3)} · acima de {m.semantic_percentile.toFixed(0)}% dos pares</p>
              </div>
              {(m.shared.genres.length > 0 || m.shared.themes.length > 0 || m.shared.text_themes.length > 0) && (
                <div>
                  <p className="eyebrow mb-1.5">Em comum</p>
                  <Tags items={[...m.shared.genres, ...new Set([...m.shared.themes, ...m.shared.text_themes])]} variant="shared" max={6} />
                </div>
              )}
              <div className="flex flex-wrap gap-2">
                <Button asChild size="sm"><Link href={`/compare/${id}/${m.author.id}`}>Comparar <ArrowRight /></Link></Button>
                <SaveButton path="/library/recommendations" label="Guardar"
                            body={{ recommended_author_id: m.author.id, source_author_id: id, context: "author_match", score: m.score }} />
              </div>
            </div>
          </li>
        ))}
      </ol>
    </>
  );
}

export default function MatchesPage() {
  return <Suspense fallback={<LoadingBlock />}><MatchesInner /></Suspense>;
}
