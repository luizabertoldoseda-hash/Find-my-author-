"use client";

import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { useApi, type Breakdown } from "@/lib/api";
import { PageHeader, Tags } from "@/components/author-bits";
import { AuthorSearch } from "@/components/author-search";
import { C1, C2, ComponentBars, StyleRadar, ThemeBars } from "@/components/charts";
import { ErrorState, LoadingBlock } from "@/components/states";

function Column({ title, items, variant }: { title: string; items: string[]; variant: "accent" | "shared" | "second" }) {
  return (
    <div>
      <p className="eyebrow mb-2">{title}</p>
      {items.length ? <Tags items={items} variant={variant} max={12} /> : <p className="text-sm text-muted">—</p>}
    </div>
  );
}

export default function ComparePage() {
  const { a, b } = useParams<{ a: string; b: string }>();
  const router = useRouter();
  const { data: d, error, loading, reload } = useApi<Breakdown>(`/matches/${a}/${b}/breakdown`);

  if (loading) return <LoadingBlock lines={10} label="Comparando autores" />;
  if (error) return <ErrorState error={error} onRetry={reload} />;
  if (!d) return null;
  const n1 = d.author1.name, n2 = d.author2.name;

  const themes = d.text_themes
    .map((t) => ({ theme: t.theme, a: t.author1, b: t.author2 }))
    .sort((x, y) => (y.a + y.b) - (x.a + x.b));

  return (
    <article className="fade-in">
      <PageHeader eyebrow="Match Breakdown" title={
        <>
          <Link href={`/authors/${d.author1.id}`} className="hover:underline" style={{ color: C1 }}>{n1}</Link>
          <span className="mx-3 font-normal italic text-muted">&amp;</span>
          <Link href={`/authors/${d.author2.id}`} className="hover:underline" style={{ color: C2 }}>{n2}</Link>
        </>
      }>
        {d.explanation}
      </PageHeader>

      <section className="grid gap-10 md:grid-cols-[1fr_1.3fr]">
        <div>
          <p className="eyebrow">Score híbrido</p>
          <p className="font-display text-8xl leading-none">{d.hybrid_score !== null ? d.hybrid_score.toFixed(2) : "—"}</p>
          <dl className="mt-6 space-y-2 text-ink-2">
            <div className="flex justify-between border-b border-rule pb-2"><dt>Cosseno dos embeddings</dt><dd className="num">{d.semantic_raw.toFixed(3)}</dd></div>
            <div className="flex justify-between border-b border-rule pb-2"><dt>Percentil entre todos os pares</dt><dd className="num">{d.semantic_percentile.toFixed(0)}º</dd></div>
            <div className="flex justify-between border-b border-rule pb-2"><dt>Posição de {n2} para {n1}</dt><dd className="num whitespace-nowrap pl-3">{d.rank_of_2_for_1}º de {d.n_authors - 1}</dd></div>
            <div className="flex justify-between border-b border-rule pb-2"><dt>Posição de {n1} para {n2}</dt><dd className="num whitespace-nowrap pl-3">{d.rank_of_1_for_2}º de {d.n_authors - 1}</dd></div>
          </dl>
        </div>
        <div>
          <h2 className="text-2xl">De onde vem o score</h2>
          <p className="mb-5 mt-1 text-sm text-ink-2">Cada componente vai de 0 a 1. Estilo é mostrado para contexto e não entra no híbrido.</p>
          <ComponentBars components={d.components as unknown as Record<string, number | null>} labels={d.component_labels} weights={d.weights} />
        </div>
      </section>

      <section className="rule-strong mt-14 pt-6">
        <h2 className="text-2xl">Gêneros, temas e vocabulário</h2>
        <div className="mt-6 grid gap-8 md:grid-cols-3">
          <div className="space-y-5 border-t-4 pt-3" style={{ borderColor: C1 }}>
            <p className="font-display text-xl">Só em {n1}</p>
            <Column title="Gêneros" items={d.only_1.genres} variant="accent" />
            <Column title="Temas" items={d.only_1.themes} variant="accent" />
            <Column title="Vocabulário" items={d.only_1.keywords} variant="accent" />
          </div>
          <div className="space-y-5 border-t-4 border-ink pt-3">
            <p className="font-display text-xl">Em comum</p>
            <Column title="Gêneros" items={d.shared.genres} variant="shared" />
            <Column title="Subgêneros" items={d.shared.subgenres} variant="shared" />
            <Column title="Temas (metadados)" items={d.shared.themes} variant="shared" />
            <Column title="Temas inferidos do texto" items={d.shared.text_themes} variant="shared" />
            <Column title="Vocabulário" items={d.shared.keywords} variant="shared" />
          </div>
          <div className="space-y-5 border-t-4 pt-3" style={{ borderColor: C2 }}>
            <p className="font-display text-xl">Só em {n2}</p>
            <Column title="Gêneros" items={d.only_2.genres} variant="second" />
            <Column title="Temas" items={d.only_2.themes} variant="second" />
            <Column title="Vocabulário" items={d.only_2.keywords} variant="second" />
          </div>
        </div>
      </section>

      <section className="rule-strong mt-14 grid gap-12 pt-6 md:grid-cols-2">
        <div>
          <h2 className="text-2xl">Estilo lado a lado</h2>
          <StyleRadar data={d.style.map((s) => ({ label: s.label, a: s.author1, b: s.author2 }))} nameA={n1} nameB={n2} height={360} />
          <details className="mt-4 text-sm">
            <summary className="eyebrow cursor-pointer">Ver valores brutos</summary>
            <table className="mt-3 w-full text-left">
              <thead><tr className="border-b border-rule"><th className="py-1 font-normal">Medida</th><th className="num font-normal">{n1}</th><th className="num font-normal">{n2}</th></tr></thead>
              <tbody>{d.style.map((s) => (
                <tr key={s.feature} className="border-b border-rule/60"><td className="py-1">{s.label}</td><td className="num">{s.author1_raw.toFixed(2)}</td><td className="num">{s.author2_raw.toFixed(2)}</td></tr>
              ))}</tbody>
            </table>
          </details>
        </div>
        <div>
          <h2 className="text-2xl">Ênfase temática comparada</h2>
          <ThemeBars data={themes} nameA={n1} nameB={n2} />
        </div>
      </section>

      <section className="rule mt-14 max-w-xl pt-6">
        <p className="eyebrow mb-2">Comparar {n1} com outro autor</p>
        <AuthorSearch exclude={[d.author1.id]} placeholder="Escolha outro autor" onPick={(x) => router.push(`/compare/${d.author1.id}/${x.id}`)} />
      </section>
    </article>
  );
}
