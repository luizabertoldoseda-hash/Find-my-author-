"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { ArrowRight } from "lucide-react";
import { useApi, type ReadingDNA } from "@/lib/api";
import { PageHeader, SaveButton, Tags, TierBadge } from "@/components/author-bits";
import { DistBars, ScoreMeter, StyleRadar, ThemeBars } from "@/components/charts";
import { EmptyState, ErrorState, LoadingBlock } from "@/components/states";

const toBars = (r: Record<string, number>) => Object.entries(r).map(([label, value]) => ({ label, value }));

export default function DNAPage() {
  const { id } = useParams<{ id: string }>();
  const { data: d, error, loading, reload } = useApi<ReadingDNA>(`/reading-dna/${id}`);

  if (loading) return <LoadingBlock lines={10} />;
  if (error) return <ErrorState error={error} onRetry={reload} />;
  if (!d) return null;
  const p = d.profile;
  const names = Object.fromEntries(d.authors.map((a) => [a.id, a.name]));
  const themes = Object.entries(p.text_theme_z).map(([theme, a]) => ({ theme, a })).sort((x, y) => y.a - x.a);
  const top = themes.slice(0, 3).map((t) => t.theme.toLowerCase());

  return (
    <article className="fade-in">
      <PageHeader eyebrow="Reading DNA" title={<>Um leitor de <em className="text-accent">{top.join(", ")}</em>.</>}>
        Perfil composto a partir de {d.authors.map((a) => a.name).join(", ")}.
      </PageHeader>

      <section className="grid gap-12 md:grid-cols-3">
        <div>
          <p className="eyebrow">Coesão do seu gosto</p>
          <p className="font-display text-7xl leading-none">{p.cohesion_percentile.toFixed(0)}<span className="text-3xl">º</span></p>
          <p className="mt-3 text-ink-2">
            Seus autores são, em média, mais parecidos entre si do que {p.cohesion_percentile.toFixed(0)}% dos pares do corpus
            <span className="num text-sm text-muted"> (cosseno médio {p.cohesion.toFixed(3)})</span>.
            {p.cohesion_percentile < 40 ? " Um gosto eclético." : p.cohesion_percentile > 75 ? " Um gosto bem definido." : ""}
          </p>
          <p className="eyebrow mt-8 mb-2">Vocabulário em comum</p>
          <p className="italic text-ink-2">{p.keywords.slice(0, 12).join(" · ") || "—"}</p>
        </div>
        <div>
          <p className="eyebrow mb-3">Gêneros (fração dos seus autores)</p>
          <DistBars data={toBars(p.genres).slice(0, 7)} />
          <p className="eyebrow mt-8 mb-3">Temas catalogados</p>
          <DistBars data={toBars(p.themes).slice(0, 7)} />
        </div>
        <div>
          <p className="eyebrow mb-1">Estilo médio</p>
          <StyleRadar data={p.style.map((s) => ({ label: s.label, a: s.value }))} nameA="Seu perfil" height={280} />
        </div>
      </section>

      <section className="rule-strong mt-14 pt-6">
        <h2 className="text-2xl">Ênfase temática do seu perfil</h2>
        <ThemeBars data={themes} nameA="Seu perfil" />
      </section>

      <section className="rule-strong mt-14 pt-6">
        <h2 className="text-3xl">Recomendados para este perfil</h2>
        <p className="mt-1 text-sm text-muted">{d.method}</p>
        {d.recommendations.length === 0 && <EmptyState title="Sem recomendações" />}
        <ol className="mt-6 grid gap-x-10 gap-y-8 md:grid-cols-2">
          {d.recommendations.map((r) => (
            <li key={r.author.id} className="border-t border-ink pt-3">
              <div className="flex items-baseline justify-between gap-3">
                <Link href={`/authors/${r.author.id}`} className="font-display text-2xl hover:text-accent">
                  <span className="num mr-2 text-sm text-muted">{String(r.rank).padStart(2, "0")}</span>{r.author.name}
                </Link>
                <span className="font-display text-2xl">{r.score.toFixed(2)}</span>
              </div>
              <ScoreMeter value={r.score} />
              <div className="mt-2"><TierBadge tier={r.author.popularity_tier} /></div>
              <p className="mt-2 text-ink-2">{r.explanation}</p>
              <Tags items={[...r.matched_genres, ...r.matched_themes]} variant="shared" />
              <div className="mt-3 flex flex-wrap items-center gap-4">
                <Link href={`/compare/${r.closest_selected}/${r.author.id}`} className="eyebrow flex items-center gap-1 hover:text-accent">
                  Comparar com {names[r.closest_selected]} <ArrowRight className="size-3" />
                </Link>
                <SaveButton path="/library/recommendations" label="Guardar"
                            body={{ recommended_author_id: r.author.id, profile_id: d.id, context: "reading_dna", score: r.score }} />
              </div>
            </li>
          ))}
        </ol>
      </section>
    </article>
  );
}
