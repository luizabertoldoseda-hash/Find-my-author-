"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { X } from "lucide-react";
import { api, useApi, type AuthorSummary, type ReadingDNA } from "@/lib/api";
import { PageHeader } from "@/components/author-bits";
import { AuthorSearch } from "@/components/author-search";
import { ErrorState } from "@/components/states";
import { Button } from "@/components/ui/button";

export default function ReadingDNAStart() {
  const router = useRouter();
  const [picked, setPicked] = useState<AuthorSummary[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<Error | null>(null);
  const past = useApi<ReadingDNA[]>("/reading-dna");

  async function generate() {
    setBusy(true);
    setErr(null);
    try {
      const r = await api<ReadingDNA>("/reading-dna", { method: "POST", body: JSON.stringify({ author_ids: picked.map((a) => a.id), k: 10 }) });
      router.push(`/reading-dna/${r.id}`);
    } catch (e) {
      setErr(e as Error);
      setBusy(false);
    }
  }

  return (
    <>
      <PageHeader eyebrow="02 · Reading DNA" title="Diga quem você lê, e nós dizemos quem você ainda vai ler.">
        Escolha de três a cinco autores favoritos. O perfil combina os textos deles numa única assinatura e procura,
        no corpus inteiro, quem mais se aproxima dela.
      </PageHeader>

      <div className="grid gap-12 md:grid-cols-[1.3fr_1fr]">
        <section>
          {picked.length < 5 ? (
            <AuthorSearch exclude={picked.map((a) => a.id)} onPick={(a) => setPicked((p) => [...p, a])}
                          placeholder={picked.length ? "Adicione mais um" : "Seu primeiro favorito"} autoFocus />
          ) : <p className="text-ink-2">Máximo de cinco autores.</p>}

          <ol className="mt-8 space-y-0 border-t border-ink">
            {Array.from({ length: 5 }).map((_, i) => {
              const a = picked[i];
              return (
                <li key={i} className="flex items-center gap-4 border-b border-rule py-3">
                  <span className="num w-6 text-sm text-muted">{i + 1}</span>
                  {a ? (
                    <>
                      <span className="flex-1 font-display text-2xl">{a.name}</span>
                      <button aria-label={`Remover ${a.name}`} onClick={() => setPicked((p) => p.filter((x) => x.id !== a.id))}
                              className="cursor-pointer text-muted hover:text-accent"><X className="size-4" /></button>
                    </>
                  ) : (
                    <span className="flex-1 italic text-muted">{i < 3 ? "obrigatório" : "opcional"}</span>
                  )}
                </li>
              );
            })}
          </ol>
          <Button className="mt-6" size="lg" variant="accent" disabled={picked.length < 3 || busy} onClick={generate}>
            {busy ? "Compondo seu perfil…" : picked.length < 3 ? `Escolha mais ${3 - picked.length}` : "Gerar meu Reading DNA"}
          </Button>
          {err && <ErrorState error={err} />}
        </section>

        <aside className="border-l border-rule pl-6">
          <p className="eyebrow">Perfis anteriores</p>
          {past.data && past.data.length === 0 && <p className="mt-3 text-muted">Você ainda não gerou nenhum perfil.</p>}
          {past.error && <p className="mt-3 text-sm text-accent">{past.error.message}</p>}
          <ul className="mt-3 space-y-4">
            {past.data?.map((p) => (
              <li key={p.id}>
                <Link href={`/reading-dna/${p.id}`} className="font-display text-lg leading-snug hover:text-accent">
                  {p.authors.map((a) => a.name).join(", ")}
                </Link>
                <p className="num text-xs text-muted">{new Date(p.created_at).toLocaleDateString("pt-BR")}</p>
              </li>
            ))}
          </ul>
        </aside>
      </div>
    </>
  );
}
